/* ============ CONTAS E SESSÃO (demonstração, tudo no navegador) ============ */
// As contas ficam no localStorage deste navegador. Não existe servidor.
// A senha nunca é guardada como texto: guardamos só um "hash" dela (SHA-256 com sal).
const CHAVE_USUARIOS = "educamat_usuarios";
const CHAVE_SESSAO = "educamat_sessao";
const CHAVE_RECUPERACAO = "educamat_recuperacao";   // códigos de recuperação de senha
const CHAVE_TROCA_EMAIL = "educamat_troca_email";   // códigos de confirmação de novo e-mail
const CHAVE_PEDIDOS = "educamat_pedidos";           // limite de pedidos de código
const CHAVE_CAIXA = "educamat_caixa";               // e-mails de demonstração (simulados)

const SENHA_MINIMA = 6;
const VALIDADE_CODIGO_MS = 30 * 60 * 1000;          // o código expira em 30 minutos
const MAX_TENTATIVAS_CODIGO = 5;                    // depois disso o código é invalidado
const MAX_PEDIDOS = 3;                              // pedidos de código por janela
const JANELA_PEDIDOS_MS = 15 * 60 * 1000;           // janela de 15 minutos

/* ---------- armazenamento ---------- */
function lerJSON(chave, padrao) {
  try { return JSON.parse(localStorage.getItem(chave)) || padrao; }
  catch (erro) { return padrao; }
}

function salvarJSON(chave, valor) {
  try { localStorage.setItem(chave, JSON.stringify(valor)); return true; }
  catch (erro) { return false; }
}

function lerUsuarios() { return lerJSON(CHAVE_USUARIOS, {}); }
function salvarUsuarios(usuarios) { return salvarJSON(CHAVE_USUARIOS, usuarios); }

/* ---------- ferramentas de segurança ---------- */
function paraHex(bytes) {
  return Array.from(bytes).map(function (b) { return b.toString(16).padStart(2, "0"); }).join("");
}

function gerarSal() {
  return paraHex(crypto.getRandomValues(new Uint8Array(16)));
}

async function gerarHash(senha, sal) {
  const dados = new TextEncoder().encode(sal + senha);
  return paraHex(new Uint8Array(await crypto.subtle.digest("SHA-256", dados)));
}

// Código numérico de 6 dígitos, sorteado com o gerador seguro do navegador
function gerarCodigo() {
  const limite = 4294000000; // maior múltiplo de 1.000.000 abaixo de 2^32 (evita viés)
  const unico = new Uint32Array(1);
  do { crypto.getRandomValues(unico); } while (unico[0] >= limite);
  return String(unico[0] % 1000000).padStart(6, "0");
}

function normalizarEmail(email) { return String(email || "").trim().toLowerCase(); }

function emailValido(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/* ---------- sessão ---------- */
// A sessão guarda o e-mail e a "versão" da conta. Trocar a senha ou encerrar
// as outras sessões aumenta a versão da conta, e sessões antigas deixam de valer.
function salvarSessao(email, usuario) {
  try { localStorage.setItem(CHAVE_SESSAO, JSON.stringify({ email: email, v: usuario.versao || 0 })); } catch (erro) {}
}

function lerSessao() {
  try {
    const bruto = localStorage.getItem(CHAVE_SESSAO);
    if (!bruto) return null;
    try {
      const sessao = JSON.parse(bruto);
      if (sessao && typeof sessao === "object") return sessao;
    } catch (e) {}
    return { email: bruto, v: 0 }; // formato antigo: só o e-mail
  } catch (erro) { return null; }
}

function usuarioLogado() {
  const sessao = lerSessao();
  if (!sessao) return null;
  const usuario = lerUsuarios()[sessao.email];
  if (!usuario || (usuario.versao || 0) !== (sessao.v || 0)) return null;
  return {
    nome: usuario.nome,
    email: sessao.email,
    foto: usuario.foto || "",
    prefs: usuario.prefs || {}
  };
}

function sair() {
  try { localStorage.removeItem(CHAVE_SESSAO); } catch (erro) {}
}

/* ---------- cadastro e login ---------- */
async function cadastrar(nome, email, senha) {
  nome = nome.trim();
  email = normalizarEmail(email);
  if (nome === "") return { ok: false, mensagem: "Digite seu nome." };
  if (!emailValido(email)) return { ok: false, mensagem: "Digite um e-mail válido." };
  if (senha.length < SENHA_MINIMA) return { ok: false, mensagem: "A senha precisa ter pelo menos " + SENHA_MINIMA + " caracteres." };

  const usuarios = lerUsuarios();
  if (usuarios[email]) return { ok: false, mensagem: "Já existe uma conta com esse e-mail." };

  const sal = gerarSal();
  usuarios[email] = { nome: nome, sal: sal, senhaHash: await gerarHash(senha, sal), versao: 0, foto: "", prefs: {} };
  if (!salvarUsuarios(usuarios)) return { ok: false, mensagem: "Não foi possível salvar a conta neste navegador." };

  salvarSessao(email, usuarios[email]);
  return { ok: true };
}

async function entrar(email, senha) {
  email = normalizarEmail(email);
  const usuario = lerUsuarios()[email];
  const erro = { ok: false, mensagem: "E-mail ou senha incorretos." };
  if (!usuario) return erro;
  if (await gerarHash(senha, usuario.sal) !== usuario.senhaHash) return erro;

  salvarSessao(email, usuario);
  return { ok: true };
}

/* ---------- e-mail de demonstração ---------- */
// Não há servidor para enviar e-mails de verdade. Esta função guarda a mensagem
// numa "caixa de entrada de demonstração" que aparece na tela.
// PARA E-MAIL REAL: troque o corpo desta função por uma chamada ao seu backend
// ou a um serviço de e-mail (EmailJS, Resend, etc.). Nada mais precisa mudar.
function enviarEmail(destino, assunto, texto) {
  const caixa = lerJSON(CHAVE_CAIXA, []);
  caixa.unshift({ para: destino, assunto: assunto, texto: texto, em: Date.now() });
  salvarJSON(CHAVE_CAIXA, caixa.slice(0, 20));
}

function lerCaixa(email) {
  email = normalizarEmail(email);
  return lerJSON(CHAVE_CAIXA, []).filter(function (m) { return m.para === email; });
}

/* ---------- recuperação de senha ---------- */
// Conta quantos pedidos foram feitos para esse e-mail na janela de tempo
function registrarPedido(email) {
  const agora = Date.now();
  const pedidos = lerJSON(CHAVE_PEDIDOS, {});
  const recentes = (pedidos[email] || []).filter(function (t) { return agora - t < JANELA_PEDIDOS_MS; });
  if (recentes.length >= MAX_PEDIDOS) return false;
  recentes.push(agora);
  pedidos[email] = recentes;
  salvarJSON(CHAVE_PEDIDOS, pedidos);
  return true;
}

const MENSAGEM_GENERICA = "Se esse e-mail estiver cadastrado, enviamos um código de 6 dígitos. Ele vale por 30 minutos.";

// A resposta é sempre a mesma, exista a conta ou não (não revela quem tem cadastro)
async function pedirRecuperacao(email) {
  email = normalizarEmail(email);
  if (!emailValido(email)) return { ok: false, mensagem: "Digite um e-mail válido." };
  if (!registrarPedido(email)) {
    return { ok: false, mensagem: "Muitos pedidos seguidos. Aguarde alguns minutos e tente de novo." };
  }
  if (lerUsuarios()[email]) {
    const codigo = gerarCodigo();
    const sal = gerarSal();
    const recuperacoes = lerJSON(CHAVE_RECUPERACAO, {});
    recuperacoes[email] = { sal: sal, hash: await gerarHash(codigo, sal), expira: Date.now() + VALIDADE_CODIGO_MS, tentativas: 0 };
    salvarJSON(CHAVE_RECUPERACAO, recuperacoes);
    enviarEmail(email, "EducaMat: código para redefinir a senha",
      "Seu código de recuperação é " + codigo + ". Ele vale por 30 minutos e só pode ser usado uma vez. " +
      "Se não foi você quem pediu, ignore esta mensagem.");
  }
  return { ok: true, mensagem: MENSAGEM_GENERICA };
}

async function redefinirSenha(email, codigo, novaSenha) {
  email = normalizarEmail(email);
  codigo = String(codigo || "").trim();
  const invalido = { ok: false, mensagem: "Código inválido ou expirado. Peça um novo código." };
  if (novaSenha.length < SENHA_MINIMA) return { ok: false, mensagem: "A nova senha precisa ter pelo menos " + SENHA_MINIMA + " caracteres." };

  const recuperacoes = lerJSON(CHAVE_RECUPERACAO, {});
  const pedido = recuperacoes[email];
  const usuarios = lerUsuarios();
  if (!pedido || !usuarios[email]) return invalido;
  if (Date.now() > pedido.expira) { delete recuperacoes[email]; salvarJSON(CHAVE_RECUPERACAO, recuperacoes); return invalido; }

  if (await gerarHash(codigo, pedido.sal) !== pedido.hash) {
    pedido.tentativas += 1;
    if (pedido.tentativas >= MAX_TENTATIVAS_CODIGO) delete recuperacoes[email];
    salvarJSON(CHAVE_RECUPERACAO, recuperacoes);
    return invalido;
  }

  const usuario = usuarios[email];
  usuario.sal = gerarSal();
  usuario.senhaHash = await gerarHash(novaSenha, usuario.sal);
  usuario.versao = (usuario.versao || 0) + 1;       // derruba as sessões antigas
  delete recuperacoes[email];                       // uso único
  if (!salvarUsuarios(usuarios)) return { ok: false, mensagem: "Não foi possível salvar a nova senha neste navegador." };
  salvarJSON(CHAVE_RECUPERACAO, recuperacoes);
  return { ok: true };
}

/* ---------- configurações da conta ---------- */
function atualizarPerfil(email, dados) {
  const usuarios = lerUsuarios();
  const usuario = usuarios[email];
  if (!usuario) return { ok: false, mensagem: "Conta não encontrada." };
  const nome = String(dados.nome || "").trim();
  if (nome === "") return { ok: false, mensagem: "Digite seu nome." };
  usuario.nome = nome;
  if (dados.foto !== undefined) usuario.foto = dados.foto;
  if (!salvarUsuarios(usuarios)) return { ok: false, mensagem: "Não foi possível salvar. A foto pode ser grande demais para este navegador." };
  return { ok: true };
}

async function alterarSenha(email, senhaAtual, novaSenha) {
  const usuarios = lerUsuarios();
  const usuario = usuarios[email];
  if (!usuario) return { ok: false, mensagem: "Conta não encontrada." };
  if (await gerarHash(senhaAtual, usuario.sal) !== usuario.senhaHash) return { ok: false, mensagem: "A senha atual está incorreta." };
  if (novaSenha.length < SENHA_MINIMA) return { ok: false, mensagem: "A nova senha precisa ter pelo menos " + SENHA_MINIMA + " caracteres." };
  if (novaSenha === senhaAtual) return { ok: false, mensagem: "A nova senha precisa ser diferente da atual." };

  usuario.sal = gerarSal();
  usuario.senhaHash = await gerarHash(novaSenha, usuario.sal);
  usuario.versao = (usuario.versao || 0) + 1;       // encerra as outras sessões
  if (!salvarUsuarios(usuarios)) return { ok: false, mensagem: "Não foi possível salvar a nova senha." };
  salvarSessao(email, usuario);                     // mantém esta sessão ativa
  return { ok: true };
}

// Encerra todas as sessões, menos a atual
function encerrarOutrasSessoes(email) {
  const usuarios = lerUsuarios();
  const usuario = usuarios[email];
  if (!usuario) return { ok: false, mensagem: "Conta não encontrada." };
  usuario.versao = (usuario.versao || 0) + 1;
  if (!salvarUsuarios(usuarios)) return { ok: false, mensagem: "Não foi possível salvar." };
  salvarSessao(email, usuario);
  return { ok: true };
}

// O novo e-mail só vale depois de o usuário digitar o código enviado para ele
async function pedirTrocaEmail(email, novoEmail, senha) {
  novoEmail = normalizarEmail(novoEmail);
  const usuarios = lerUsuarios();
  const usuario = usuarios[email];
  if (!usuario) return { ok: false, mensagem: "Conta não encontrada." };
  if (await gerarHash(senha, usuario.sal) !== usuario.senhaHash) return { ok: false, mensagem: "A senha está incorreta." };
  if (!emailValido(novoEmail)) return { ok: false, mensagem: "Digite um e-mail válido." };
  if (novoEmail === email) return { ok: false, mensagem: "Esse já é o seu e-mail atual." };
  if (usuarios[novoEmail]) return { ok: false, mensagem: "Já existe uma conta com esse e-mail." };
  if (!registrarPedido(novoEmail)) return { ok: false, mensagem: "Muitos pedidos seguidos. Aguarde alguns minutos e tente de novo." };

  const codigo = gerarCodigo();
  const sal = gerarSal();
  const trocas = lerJSON(CHAVE_TROCA_EMAIL, {});
  trocas[email] = { novoEmail: novoEmail, sal: sal, hash: await gerarHash(codigo, sal), expira: Date.now() + VALIDADE_CODIGO_MS, tentativas: 0 };
  salvarJSON(CHAVE_TROCA_EMAIL, trocas);
  enviarEmail(novoEmail, "EducaMat: confirme seu novo e-mail",
    "Seu código para confirmar este e-mail é " + codigo + ". Ele vale por 30 minutos.");
  return { ok: true, novoEmail: novoEmail };
}

async function confirmarTrocaEmail(email, codigo) {
  codigo = String(codigo || "").trim();
  const invalido = { ok: false, mensagem: "Código inválido ou expirado." };
  const trocas = lerJSON(CHAVE_TROCA_EMAIL, {});
  const pedido = trocas[email];
  const usuarios = lerUsuarios();
  if (!pedido || !usuarios[email]) return invalido;
  if (Date.now() > pedido.expira) { delete trocas[email]; salvarJSON(CHAVE_TROCA_EMAIL, trocas); return invalido; }

  if (await gerarHash(codigo, pedido.sal) !== pedido.hash) {
    pedido.tentativas += 1;
    if (pedido.tentativas >= MAX_TENTATIVAS_CODIGO) delete trocas[email];
    salvarJSON(CHAVE_TROCA_EMAIL, trocas);
    return invalido;
  }
  if (usuarios[pedido.novoEmail]) { delete trocas[email]; salvarJSON(CHAVE_TROCA_EMAIL, trocas); return { ok: false, mensagem: "Esse e-mail já foi cadastrado por outra conta." }; }

  // a conta passa a ser identificada pelo novo e-mail
  const usuario = usuarios[email];
  delete usuarios[email];
  usuarios[pedido.novoEmail] = usuario;
  if (!salvarUsuarios(usuarios)) return { ok: false, mensagem: "Não foi possível salvar o novo e-mail." };
  delete trocas[email];
  salvarJSON(CHAVE_TROCA_EMAIL, trocas);
  const recuperacoes = lerJSON(CHAVE_RECUPERACAO, {});
  delete recuperacoes[email];
  salvarJSON(CHAVE_RECUPERACAO, recuperacoes);
  salvarSessao(pedido.novoEmail, usuario);
  return { ok: true, email: pedido.novoEmail };
}

function salvarPreferencias(email, prefs) {
  const usuarios = lerUsuarios();
  if (!usuarios[email]) return { ok: false, mensagem: "Conta não encontrada." };
  usuarios[email].prefs = Object.assign({}, usuarios[email].prefs, prefs);
  return salvarUsuarios(usuarios) ? { ok: true } : { ok: false, mensagem: "Não foi possível salvar." };
}

async function excluirConta(email, senha) {
  const usuarios = lerUsuarios();
  const usuario = usuarios[email];
  if (!usuario) return { ok: false, mensagem: "Conta não encontrada." };
  if (await gerarHash(senha, usuario.sal) !== usuario.senhaHash) return { ok: false, mensagem: "A senha está incorreta." };
  delete usuarios[email];
  if (!salvarUsuarios(usuarios)) return { ok: false, mensagem: "Não foi possível excluir a conta." };
  [CHAVE_RECUPERACAO, CHAVE_TROCA_EMAIL].forEach(function (chave) {
    const dados = lerJSON(chave, {});
    delete dados[email];
    salvarJSON(chave, dados);
  });
  sair();
  return { ok: true };
}
