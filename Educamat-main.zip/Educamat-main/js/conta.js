/* ============ MINHA CONTA e RECUPERAÇÃO DE SENHA (telas) ============ */
let contaAberta = false;     // a tela "Minha conta" está visível?
let recuperando = false;     // a tela "Recuperar senha" está visível?
let emailRecuperacao = "";   // e-mail que pediu o código

function $(id) { return document.getElementById(id); }

function mostrarMensagem(id, texto, tipo) {
  const el = $(id);
  el.textContent = texto;
  el.className = tipo === "ok" ? "sucesso" : "aviso";
  el.hidden = false;
}

function esconderMensagem(id) { $(id).hidden = true; }

function temCripto() { return !!(window.crypto && crypto.subtle); }

/* ---------- tema e foto ---------- */
function aplicarTema(tema) {
  if (tema === "light" || tema === "dark") document.documentElement.setAttribute("data-theme", tema);
  else document.documentElement.removeAttribute("data-theme");
}

function desenharAvatar(img, inicial, foto, nome) {
  if (foto) { img.src = foto; img.hidden = false; if (inicial) inicial.hidden = true; }
  else { img.removeAttribute("src"); img.hidden = true; if (inicial) { inicial.hidden = false; inicial.textContent = (nome || "?").trim().charAt(0).toUpperCase(); } }
}

// Chamada por login.js sempre que a tela principal é atualizada
function atualizarTelasConta(usuario) {
  if (usuario) {
    recuperando = false;
    $("tela-recuperar").hidden = true;
    $("tela-conta").hidden = !contaAberta;
    $("tela-teste").hidden = contaAberta;
    desenharAvatar($("barra-avatar"), null, usuario.foto, usuario.nome);
    aplicarTema(usuario.prefs.tema);
  } else {
    contaAberta = false;
    $("tela-conta").hidden = true;
    $("tela-login").hidden = recuperando;
    $("tela-recuperar").hidden = !recuperando;
    aplicarTema("auto");
  }
}

function atualizarTudo() {
  if (typeof atualizarTela === "function") atualizarTela();
  else atualizarTelasConta(usuarioLogado());
}

/* ---------- caixa de e-mail de demonstração ---------- */
function mostrarCaixa(idCaixa, email) {
  const caixa = $(idCaixa);
  const mensagens = lerCaixa(email);
  caixa.innerHTML = "";
  const titulo = document.createElement("strong");
  titulo.textContent = "E-mails de demonstração para " + email;
  caixa.appendChild(titulo);
  if (mensagens.length === 0) {
    const vazio = document.createElement("p");
    vazio.textContent = "Nenhum e-mail por aqui.";
    caixa.appendChild(vazio);
  }
  mensagens.slice(0, 3).forEach(function (m) {
    const item = document.createElement("div");
    item.className = "email-item";
    const assunto = document.createElement("b");
    assunto.textContent = m.assunto;
    const texto = document.createElement("p");
    texto.textContent = m.texto;
    item.appendChild(assunto);
    item.appendChild(texto);
    caixa.appendChild(item);
  });
  caixa.hidden = false;
}

/* ---------- recuperar senha ---------- */
function abrirRecuperacao() {
  recuperando = true;
  emailRecuperacao = "";
  $("form-recuperar-pedido").hidden = false;
  $("form-recuperar-codigo").hidden = true;
  $("form-recuperar-pedido").reset();
  $("form-recuperar-codigo").reset();
  esconderMensagem("msg-rec-pedido");
  esconderMensagem("msg-rec-codigo");
  $("caixa-recuperar").hidden = true;
  $("rec-email").value = $("email").value;
  atualizarTudo();
  $("rec-email").focus();
}

function fecharRecuperacao() {
  recuperando = false;
  atualizarTudo();
}

$("link-esqueci").addEventListener("click", function (e) { e.preventDefault(); abrirRecuperacao(); });
$("rec-voltar").addEventListener("click", fecharRecuperacao);

$("rec-ver-caixa").addEventListener("click", function () {
  const email = emailRecuperacao || normalizarEmail($("rec-email").value);
  if (!email) { mostrarMensagem("msg-rec-pedido", "Digite seu e-mail primeiro."); return; }
  mostrarCaixa("caixa-recuperar", email);
});

$("form-recuperar-pedido").addEventListener("submit", async function (e) {
  e.preventDefault();
  if (!temCripto()) { mostrarMensagem("msg-rec-pedido", "Este navegador não permite a recuperação. Use um navegador atual."); return; }
  const resposta = await pedirRecuperacao($("rec-email").value);
  if (!resposta.ok) { mostrarMensagem("msg-rec-pedido", resposta.mensagem); return; }
  emailRecuperacao = normalizarEmail($("rec-email").value);
  esconderMensagem("msg-rec-pedido");
  $("msg-rec-enviado").textContent = resposta.mensagem;
  $("form-recuperar-pedido").hidden = true;
  $("form-recuperar-codigo").hidden = false;
  $("rec-codigo").focus();
});

$("form-recuperar-codigo").addEventListener("submit", async function (e) {
  e.preventDefault();
  const nova = $("rec-nova").value;
  if (nova !== $("rec-confirma").value) { mostrarMensagem("msg-rec-codigo", "As senhas não são iguais."); return; }
  const resposta = await redefinirSenha(emailRecuperacao, $("rec-codigo").value, nova);
  if (!resposta.ok) { mostrarMensagem("msg-rec-codigo", resposta.mensagem); return; }
  // volta para o login com o e-mail já preenchido
  const email = emailRecuperacao;
  recuperando = false;
  escolherModo(false);
  $("email").value = email;
  $("senha").value = "";
  atualizarTudo();
  mostrarMensagem("mensagem-login", "Senha alterada! Entre com a nova senha.", "ok");
  $("senha").focus();
});

/* ---------- abrir e fechar Minha conta ---------- */
function mostrarAba(nome) {
  document.querySelectorAll(".abas-conta .aba").forEach(function (aba) {
    aba.setAttribute("aria-selected", String(aba.dataset.aba === nome));
  });
  document.querySelectorAll("[data-painel]").forEach(function (painel) {
    painel.hidden = painel.dataset.painel !== nome;
  });
}

function preencherConta() {
  const usuario = usuarioLogado();
  if (!usuario) return;
  $("perfil-nome").value = usuario.nome;
  $("email-atual").textContent = usuario.email;
  desenharAvatar($("perfil-avatar"), $("perfil-inicial"), usuario.foto, usuario.nome);
  $("pref-tema").value = usuario.prefs.tema || "auto";
  $("pref-avisos").checked = usuario.prefs.avisos !== false;
  ["form-email", "form-email-codigo", "form-senha", "form-excluir"].forEach(function (id) { $(id).reset(); });
  fotoNova = undefined;
  $("form-email-codigo").hidden = true;
  $("caixa-conta").hidden = true;
  ["msg-perfil", "msg-email", "msg-email-codigo", "msg-senha", "msg-sessoes", "msg-prefs", "msg-excluir"].forEach(esconderMensagem);
}

$("botao-conta").addEventListener("click", function () {
  contaAberta = true;
  preencherConta();
  mostrarAba("perfil");
  atualizarTudo();
  window.scrollTo(0, 0);
});

$("conta-voltar").addEventListener("click", function () { contaAberta = false; atualizarTudo(); });

document.querySelectorAll(".abas-conta .aba").forEach(function (aba) {
  aba.addEventListener("click", function () { mostrarAba(aba.dataset.aba); });
});

/* ---------- meu perfil ---------- */
let fotoNova;  // undefined = não mudou; "" = remover; texto = nova foto

// Reduz a foto para 160x160 para caber no armazenamento do navegador
function reduzirFoto(arquivo) {
  return new Promise(function (resolver, rejeitar) {
    const leitor = new FileReader();
    leitor.onerror = rejeitar;
    leitor.onload = function () {
      const img = new Image();
      img.onerror = rejeitar;
      img.onload = function () {
        const lado = Math.min(img.width, img.height);
        const canvas = document.createElement("canvas");
        canvas.width = canvas.height = 160;
        canvas.getContext("2d").drawImage(img, (img.width - lado) / 2, (img.height - lado) / 2, lado, lado, 0, 0, 160, 160);
        resolver(canvas.toDataURL("image/jpeg", 0.8));
      };
      img.src = leitor.result;
    };
    leitor.readAsDataURL(arquivo);
  });
}

$("perfil-foto").addEventListener("change", async function () {
  const arquivo = this.files[0];
  if (!arquivo) return;
  if (!arquivo.type.startsWith("image/")) { mostrarMensagem("msg-perfil", "Escolha um arquivo de imagem."); return; }
  try {
    fotoNova = await reduzirFoto(arquivo);
    desenharAvatar($("perfil-avatar"), $("perfil-inicial"), fotoNova, $("perfil-nome").value);
    mostrarMensagem("msg-perfil", "Foto escolhida. Clique em Salvar perfil.", "ok");
  } catch (erro) {
    mostrarMensagem("msg-perfil", "Não foi possível ler essa imagem.");
  }
});

$("perfil-remover-foto").addEventListener("click", function () {
  fotoNova = "";
  desenharAvatar($("perfil-avatar"), $("perfil-inicial"), "", $("perfil-nome").value);
  mostrarMensagem("msg-perfil", "Foto removida. Clique em Salvar perfil.", "ok");
});

$("form-perfil").addEventListener("submit", function (e) {
  e.preventDefault();
  const usuario = usuarioLogado();
  const resposta = atualizarPerfil(usuario.email, { nome: $("perfil-nome").value, foto: fotoNova });
  if (!resposta.ok) { mostrarMensagem("msg-perfil", resposta.mensagem); return; }
  fotoNova = undefined;
  mostrarMensagem("msg-perfil", "Perfil salvo!", "ok");
  const atual = usuarioLogado();
  $("saudacao").textContent = "Olá, " + atual.nome;
  desenharAvatar($("barra-avatar"), null, atual.foto, atual.nome);
});

/* ---------- trocar e-mail ---------- */
let novoEmailPendente = "";

$("form-email").addEventListener("submit", async function (e) {
  e.preventDefault();
  if (!temCripto()) { mostrarMensagem("msg-email", "Este navegador não permite essa ação."); return; }
  const usuario = usuarioLogado();
  const resposta = await pedirTrocaEmail(usuario.email, $("novo-email").value, $("email-senha").value);
  if (!resposta.ok) { mostrarMensagem("msg-email", resposta.mensagem); return; }
  novoEmailPendente = resposta.novoEmail;
  mostrarMensagem("msg-email", "Enviamos um código para " + resposta.novoEmail + ". Digite-o abaixo para confirmar.", "ok");
  $("form-email-codigo").hidden = false;
  $("email-codigo").focus();
});

$("email-caixa").addEventListener("click", function () { mostrarCaixa("caixa-conta", novoEmailPendente); });

$("form-email-codigo").addEventListener("submit", async function (e) {
  e.preventDefault();
  const usuario = usuarioLogado();
  const resposta = await confirmarTrocaEmail(usuario.email, $("email-codigo").value);
  if (!resposta.ok) { mostrarMensagem("msg-email-codigo", resposta.mensagem); return; }
  preencherConta();
  mostrarMensagem("msg-email", "E-mail alterado para " + resposta.email + ".", "ok");
});

/* ---------- segurança ---------- */
$("form-senha").addEventListener("submit", async function (e) {
  e.preventDefault();
  const nova = $("senha-nova").value;
  if (nova !== $("senha-confirma").value) { mostrarMensagem("msg-senha", "As senhas não são iguais."); return; }
  const usuario = usuarioLogado();
  const resposta = await alterarSenha(usuario.email, $("senha-atual").value, nova);
  if (!resposta.ok) { mostrarMensagem("msg-senha", resposta.mensagem); return; }
  $("form-senha").reset();
  mostrarMensagem("msg-senha", "Senha alterada! As outras sessões foram encerradas.", "ok");
});

$("botao-outras-sessoes").addEventListener("click", function () {
  const resposta = encerrarOutrasSessoes(usuarioLogado().email);
  mostrarMensagem("msg-sessoes", resposta.ok ? "Pronto: as outras sessões foram encerradas." : resposta.mensagem, resposta.ok ? "ok" : "erro");
});

/* ---------- preferências ---------- */
$("pref-tema").addEventListener("change", function () {
  const resposta = salvarPreferencias(usuarioLogado().email, { tema: this.value });
  aplicarTema(this.value);
  mostrarMensagem("msg-prefs", resposta.ok ? "Preferência salva." : resposta.mensagem, resposta.ok ? "ok" : "erro");
});

$("pref-avisos").addEventListener("change", function () {
  const resposta = salvarPreferencias(usuarioLogado().email, { avisos: this.checked });
  mostrarMensagem("msg-prefs", resposta.ok ? "Preferência salva." : resposta.mensagem, resposta.ok ? "ok" : "erro");
});

/* ---------- excluir conta ---------- */
$("form-excluir").addEventListener("submit", async function (e) {
  e.preventDefault();
  if (!temCripto()) { mostrarMensagem("msg-excluir", "Este navegador não permite essa ação."); return; }
  if (!confirm("Tem certeza? Sua conta será apagada e isso não pode ser desfeito.")) return;
  const resposta = await excluirConta(usuarioLogado().email, $("excluir-senha").value);
  if (!resposta.ok) { mostrarMensagem("msg-excluir", resposta.mensagem); return; }
  contaAberta = false;
  $("form-excluir").reset();
  document.getElementById("resultado").hidden = true;
  atualizarTudo();
});
